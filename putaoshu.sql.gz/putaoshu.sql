-- phpMyAdmin SQL Dump
-- version 3.3.7
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2014 年 01 月 15 日 02:24
-- 服务器版本: 5.0.90
-- PHP 版本: 5.2.14

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `putaoshu`
--

-- --------------------------------------------------------

--
-- 表的结构 `yk_article`
--
-- 创建时间: 2014 年 01 月 08 日 15:22
-- 最后更新: 2014 年 01 月 15 日 10:17
--

CREATE TABLE IF NOT EXISTS `yk_article` (
  `aid` int(12) unsigned NOT NULL auto_increment COMMENT 'ID',
  `title` varchar(200) NOT NULL COMMENT '标题',
  `shortdesc` varchar(500) default NULL COMMENT '简介',
  `content` text character set ucs2 COMMENT '内容',
  `picture` varchar(500) default NULL COMMENT '图片路径',
  `createtime` varchar(50) NOT NULL COMMENT '创建时间',
  `updatetime` varchar(50) default NULL COMMENT '更新时间',
  `cat_id` int(10) NOT NULL COMMENT '所属栏目',
  `url` varchar(100) default NULL COMMENT 'URL地址',
  `review_number` int(12) NOT NULL default '0' COMMENT '评论个数',
  `praise_number` int(12) NOT NULL default '0' COMMENT '“赞”个数',
  PRIMARY KEY  (`aid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=90 ;

--
-- 转存表中的数据 `yk_article`
--

INSERT INTO `yk_article` (`aid`, `title`, `shortdesc`, `content`, `picture`, `createtime`, `updatetime`, `cat_id`, `url`, `review_number`, `praise_number`) VALUES
(14, '[心灵花园]第一期第一版', '', '<h3 class="headline-2" style="font-size:16px;font-family:Arial;background-color:#FFFFFF;">\r\n	<span class="headline-content">追溯奠基</span> \r\n</h3>\r\n<div class="para" style="font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	小说的奠基历经先秦、两汉、魏晋南北朝八百多年的积累和沉淀，当历史进入唐代小说才正式形成。追溯八百多年的奠基，主要表现在四个方面：\r\n</div>\r\n<div class="para" style="font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	一是寓言故事。如《》、《》、《》、《》，等书中都有不少人物性格鲜明的寓言故事，它们已经带有小说的意味。\r\n</div>\r\n<div class="para" style="font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	二是史传。如《》、《》、《》、《》，描写人物性格，叙述故事情节，或为小说提供了素材，或为小说积累了叙事的经验。\r\n</div>\r\n<div class="para" style="font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	三是文人笔记。这一点在魏晋南北朝时期尤为明显，文人笔记大都记载一些轶事、掌故、素材。\r\n</div>\r\n<div class="para" style="font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	四是民间娱乐消闲。各朝代都有茶馆饭店常驻的说话人、说书人，以话本为基础，每天把故事小小的说一段（小说），以吸引客人每天回来听书，希望保证生意兴隆。\r\n</div>', 'article_pic/1378979640.jpg', '1379037214', '1379991391', 8, '', 0, 3),
(15, '[心灵花园]第一期第二版', '', '<h3 class="headline-2" style="font-size:16px;font-family:Arial;background-color:#FFFFFF;">\r\n	<span class="headline-content">价值性</span> \r\n</h3>\r\n<div class="para" style="font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	小说的价值本质是以为序列、以某一或几个人物为的，非常详细地、全面地反映社会生活中各种角色的价值关系（、和文化关系）的产生、发展与消亡过程。非常细致地、综合地展示各种价值关系的相互作用。\r\n</div>\r\n<h3 class="headline-2" style="font-size:16px;font-family:Arial;background-color:#FFFFFF;">\r\n	<span class="headline-content">容量性</span> \r\n</h3>\r\n<div class="para" style="font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	与其他文学样式相比，小说的容量较大，它可以地展现人物性格和人物命运，可以表现错综复杂的矛盾冲突，同时还可以描述人物所处的社会生活环境。小说的优势是可以提供整体的、的社会生活。\r\n</div>\r\n<h3 class="headline-2" style="font-size:16px;font-family:Arial;background-color:#FFFFFF;">\r\n	<span class="headline-content">情节性</span> \r\n</h3>\r\n<div class="para" style="font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	小说主要是通过情节来展现人物性格、表现中心的。故事来源于生活，但它通过整理、提炼和安排，就比现实生活中发生的真实更集中，更完整，更具有代表性。\r\n</div>\r\n<h3 class="headline-2" style="font-size:16px;font-family:Arial;background-color:#FFFFFF;">\r\n	<span class="headline-content">环境性</span> \r\n</h3>\r\n<div class="para" style="font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	小说的环境描写和人物的塑造与中心思想有极其重要的关系。在环境描写中，社会环境是重点，它揭示了种种复杂的社会关系，如人物的、地位、的历史背景等等。自然环境包括人物活动的地点、时间、季节、气候以及景物等等。自然环境描写对表达人物的<i>、</i>渲染气氛都有不少的作用。\r\n</div>', 'article_pic/1378979655.jpg', '1379037229', '1379991386', 8, '', 2, 2),
(16, '[心灵花园]第一期第三版', '', '<h3 class="headline-2" style="font-size:16px;font-family:Arial;background-color:#FFFFFF;">\r\n	<span class="headline-content">历史</span> \r\n</h3>\r\n<div class="para" style="font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	「小说」一词最早出现于《．外物》：「饰小说以干，其於大达亦远矣。」庄子所谓的「小说」，是指的言论，与今日小说观念相差甚远。直至东汉《新论》：「小说家合残丛小语，近取譬喻，以作短书，治身理家，有可观之辞。」班固《．艺文志》将「小说家」列为十家之後，其下的定义为：「小说家者流，盖出於稗官，街谈巷语，道听涂说[4]之所造也。」才稍与日小说的意义相近。\r\n</div>\r\n<h3 class="headline-2" style="font-size:16px;font-family:Arial;background-color:#FFFFFF;">\r\n	<span class="headline-content">中国小说</span> \r\n</h3>\r\n<div class="para" style="font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	而中国小说最大的，便自开始具有与两种不同的小说系统。文言小说起源於先秦的街谈巷语，是一种小知小道的纪录。在历经魏晋南北朝及隋唐长期的发展，无论是题材或人物的描写，文言小说都有明显的进步，形成笔记与传奇两种小说类型。而白话小说则起源於唐宋时期说话人的话本，故事的取材来自民间，主要表现了百姓的生活及思想意识。但不管小说或白话小说都源远流长，呈现各自不同的艺术特色\r\n</div>', 'article_pic/1379037203.jpg', '1379037203', '1379991379', 8, '', 2, 3),
(17, '淘宝', '微淘优化、机票优化、淘宝同城', '<span style="color:#555555;font-family:Arial;line-height:25px;">【微淘优化】</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">1.可以收藏喜欢的广播</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">2.评论支持回复功能</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">3.针对新用户推荐热门的微淘账号</span><br />\r\n<br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">【机票优化】</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">1.打通机票活动平台，主站可参加机票活动</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">2.保险分润，机票保险一起买省￥15</span><br />\r\n<br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">【淘宝同城】</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">新增淘宝同城可帮您找到附近优质商户，便捷付款并享受优惠，目前仅在杭州地区使用</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">1.快速查找周边商户，购买现金券享受优惠，更省钱</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">2.扫码支付更方便，不用带钱包</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">3.消费支付之后还能刮奖，集分宝、实物大奖等你拿</span>', 'article_pic/1379055550.png', '1379055550', '1379469399', 12, 'http://as.baidu.com/a?pre=web_am_header&f=web_alad_5%40next', 0, 0),
(18, '美团团购', '美团团购，口碑最好、国内最火的团购必备软件', '<span style="color:#555555;font-family:Arial;line-height:25px;">1、随时随查看周边美食、电影、酒店等团购优惠及兑换券信息；</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">2、团购筛选排序：支持按品类或商圈筛选，按距离人气排序，查找更方便；</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">3、手机支付快速秒杀；</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">4、美团券到期提醒；</span><br />\r\n<br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">5、支持手机退款：消费不满意，美团就免单。</span>', 'article_pic/1379055592.png', '1379055592', '1379469392', 12, 'http://as.baidu.com/a?pre=web_am_header&f=web_alad_5%40next', 0, 0),
(19, '易外卖', '不想出门，发现手上没外卖单，肿么办？', '<span style="color:#555555;font-family:Arial;line-height:25px;">用餐三步走</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">1、找餐</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">根据您的位置提供周边外卖，不管您身处何处，都能轻松找到美食。</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">2、点餐</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">浏览您喜欢的外卖店铺，挑选美食菜肴，确认并提交您的订单。</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">3、用餐</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">关注您的订单状态，审核通过后，等待美食上门。</span>', 'article_pic/1379055629.png', '1379055629', '1379055753', 14, 'http://as.baidu.com/a?pre=web_am_header&f=web_alad_5%40next', 0, 0),
(20, '美食天下', '美食家最多、使用范围最广、功能最全的手机菜谱软件', '<span style="color:#555555;font-family:Arial;line-height:25px;">每天：为您推荐最热的优秀菜谱和优秀专题,每天,都是一家人味蕾的无尽期待。</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">搜索：强大的网络搜索功能,可按菜名、按食材名,迅速检索美食天下的所有菜谱。&nbsp;</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">分类：提供多种分类查看方式，如按食疗、地区方式、家常、按人群、食材、口味等等。&nbsp;</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">会员：&nbsp;与美食天下网站通用的会员系统,您可以直接登录,或者免费注册新会员。无论在手机还是在电脑上,您的操作都将自动同步，上传您的原创作品；</span>', 'article_pic/1379055665.png', '1379055665', '1379055665', 14, 'http://as.baidu.com/a?pre=web_am_header&f=web_alad_5%40next', 0, 0),
(21, '快速问医生', '问医生、查疾病，放不下的健康，舍不掉的应用', '<span style="color:#555555;font-family:Arial;line-height:25px;">1、问医生：比你更懂你--最简单、最快速咨询健康问题；</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">2、查疾病：一般人我不告诉他--最全面、最权威的疾病数据库；</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">3、逛圈子：你有我有全都有--话题凝聚经验，经验传递健康；</span><br />\r\n<span style="color:#555555;font-family:Arial;line-height:25px;">4、家庭医生：家庭医生不止是富人家庭才会拥有的，在这里，你即可拥有；</span>', 'article_pic/1379055696.png', '1379055696', '1379055696', 14, 'http://as.baidu.com/a?pre=web_am_header&f=web_alad_5%40next', 0, 0),
(22, '上滑图片01', '', '', 'article_pic/1385967564.jpg', '1379060195', '1385967564', 1, '', 0, 0),
(23, '上滑图片02', '', '', 'article_pic/1385967556.jpg', '1379060489', '1385967556', 1, '', 0, 0),
(24, '上滑图片03', '', '', 'article_pic/1385967545.jpg', '1379060500', '1385967545', 1, '', 0, 0),
(25, '上滑图片04', '', '', 'article_pic/1385099925.jpg', '1379060511', '1385965172', 1, '', 0, 0),
(26, '侍酒师“世界杯”决赛将于10月在南非举行', '侍酒师“世界杯”由南非葡萄酒协会(WOSA)主办，选拔赛主要比赛环节包括：30分钟内盲品6款南非葡萄酒；推荐3款南非葡萄酒搭配食物；展示开瓶等侍酒基本技能；更正一份有错误的酒单；应对“食客”扮演者随时', '<p style="text-align:center;font-family:����;font-size:14px;">\r\n	<span style="line-height:1.5;"><img src="http://192.168.1.104/wine2/code/editor/attached/image/20130916/20130916105013_36109.jpg" alt="" /><br />\r\n</span> \r\n</p>\r\n<p style="text-align:center;font-family:����;font-size:14px;">\r\n	<span style="line-height:1.5;">玩过足球“世界杯”的南非，2010年首次举办侍酒师“世界杯”比赛(WOSA Sommelier Cup)。今年举办的第二届侍酒师“世界杯”亚洲地区选拔赛，已于近日分别在北京和香港举行。北京赛区有来自北京和上海等城市的7名选手参加角逐，最终由上海外滩游艇俱乐部首席侍酒师张聪夺得冠军；香港赛区有来自港澳台地区及韩国、泰国、马来西亚的8名选手参加角逐，最终由ASC精品酒业公司教育和培训经理陈家濠夺得冠军。决赛将于今年10月7日至13日在南非举行，张聪和陈家濠将迎战来自比利时、德国、英国、荷兰、瑞典、挪威、芬兰、俄罗斯、加拿大和美国等国家的10位选手。</span> \r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　侍酒师“世界杯”由南非葡萄酒协会(WOSA)主办，选拔赛主要比赛环节包括：30分钟内盲品6款南非葡萄酒；推荐3款南非葡萄酒搭配食物；展示开瓶等侍酒基本技能；更正一份有错误的酒单；应对“食客”扮演者随时提出的“刁难”问题。\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	<br />\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　据悉，首届侍酒师“世界杯”比赛冠军、美国选手克里斯托弗•贝茨，已于今年5月加冕侍酒大师评审会(The Court of Master Sommeliers)授予的“侍酒大师”头衔，成为北美地区的133位“侍酒大师”之一。\r\n</p>', 'article_pic/1379124029.jpg', '1379124029', '1379299823', 3, NULL, 0, 6),
(27, '2013第二届长城葡萄酒杯 RVF CHINA品酒师大赛火热开赛', '由中国食品有限公司和财讯传媒集团旗下《葡萄酒评论》杂志共同举办的2013第二届长城葡萄酒杯RVFCHINA品酒师大赛初赛于7月27日10点整在北京华腾美居酒店正式拉开战幕。经过3个月的前期宣传招募，共', '<p>\r\n	<span style="font-family:����;font-size:14px;line-height:26px;">由中国食品有限公司和财讯传媒集团旗下《葡萄酒评论》杂志共同举办的2013第二届长城葡萄酒杯RVFCHINA品酒师大赛初赛于7月27日10点整在北京华腾美居酒店正式拉开战幕。经过3个月的前期宣传招募，共有400多位来自葡萄酒行业内外的精英们踏上了品酒师大赛的精彩之旅。</span>\r\n</p>\r\n<p>\r\n	<span style="font-family:����;font-size:14px;line-height:26px;"></span>\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	初赛当日，来自全国各地及国外的葡萄酒专业人员或爱好者们状态表现良好，数十位业内权威专家齐集一堂，共同见证了这一葡萄酒行业重要盛世。专家们表示，长城葡萄酒杯RVFCHINA品酒师大赛为行业内注入了一股新鲜血液，为选手们搭建了一个宽广的专业平台，从获得国家品酒师一、二、三级专业证书到拥有巴黎葡萄酒学院证书，最后站上世界品酒师大赛的国际舞台，大赛在推动中国葡萄酒行业全面健康国际化发展的道路上不遗余力，是行业内不可多得的重要赛事。\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　大赛理论考试从上午十点正式开始，经过一个半小时的基础品酒师理论知识的全面考察，使选手们对自己的理论水平有了准确的定位。接下来进行的是长达四个小时的实操考核，选手们深刻体会到了成为一名合格的品酒师所需具备的基本实战技能。考核共分6个轮次进行，每个轮次品评时间从15分钟到30分钟不等，每位选手在每个轮次对5个酒杯中的溶液成分阈值或酿酒葡萄品种进行品评鉴别。在阈值考核部分主要包括味觉阈值测定、香气浓度鉴别、糖度排序、酸度排序等；在酿酒葡萄品种品评鉴别中，需要选手能够全面熟练认知常见酿酒葡萄的特性，进而准确标出五个酒杯中的酿酒葡萄品种。\r\n</p>\r\n<div>\r\n	<br />\r\n</div>', 'article_pic/1379124064.jpg', '1379124064', '1379124064', 3, NULL, 0, 6),
(28, '2014年世界葡萄大会将在北京延庆县举办', '明年7月29日至8月2日，世界葡萄大会将首次走进亚洲，在北京延庆县举办。昨天（29日），延庆县举行了世葡会倒计时一周年新闻发布会，发布了大会会标和主题口号。', '<p style="font-family:����;font-size:14px;">\r\n	明年7月29日至8月2日，世界葡萄大会将首次走进亚洲，在北京延庆县举办。昨天（29日），延庆县举行了世葡会倒计时一周年新闻发布会，发布了大会会标和主题口号。与往届不同，本届大会突破了单一的学术会议内容，增加了葡萄酒博览会、葡萄酒品鉴大赛、产经论坛等内容。\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　昨天的新闻发布会搬到了室外，在主会场酒店所在地的草坪上举行。大会指挥部发布了大会会标和主题口号，并启动了主题歌和吉祥物的征集活动。“相约长城，品味自然”被确定为大会主题口号，会标是由一条由绿变紫色的丝带，缠绕出长城、葡萄、中国结等象征图案，表达了“分享、交流、合作”的理念与发展前景。\r\n</p>', 'article_pic/1379124098.jpg', '1379124098', '1379124098', 3, NULL, 0, 7),
(29, '第三期“葡萄酒学院•逸香ESW品酒师中级课程”圆满结束', '　7月初，由西北农林科技大学葡萄酒学院、北京逸香世纪葡萄酒文化传播有限公司，保乐力加(中国)贸易有限公司三方联合发起的“葡萄酒学院•逸香ESW品酒师中级课程”第三期圆满结束了。', '<p style="font-family:����;font-size:14px;">\r\n	　7月初，由西北农林科技大学葡萄酒学院、北京逸香世纪葡萄酒文化传播有限公司，保乐力加(中国)贸易有限公司三方联合发起的“葡萄酒学院•逸香ESW品酒师中级课程”第三期圆满结束了。\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　第三届培训班主要针对葡萄酒学院的大三升大四的同学，共有46位学生参加，目的是拓宽同学的视野，思考未来的发展方向，尤其是在品酒水平方面能有一个系统的训练和提升。北京逸香世纪葡萄酒文化传播有限公司的高级讲师陈洁女士为学生们授课，陈老师不但系统地讲解了ESW品酒师中级课程的葡萄酒知识，更多地分享了国际国内市场、消费者行为、产业发展前景方面的信息，使同学们受益颇多。<br />\r\n　<br />\r\n　　课上，学员们通过本土模块及实操练习，对葡萄酒基础知识的运用有了切身体会与实战经验。课下，学员们反映课程的设置对他们的择业有很大的帮助，对开阔视野、拓宽知识有明确的指导性，今后他们在葡萄酒行业的发展有了更细致的规划。同时，学员们也表示他们对葡萄酒基础教育以外的知识十分渴望，希望可以通过逸香葡萄酒教育获得更多国内外最新葡萄酒资讯。<br />\r\n　<br />\r\n　　“葡萄酒学院•逸香ESW品酒师中级课程”第三期的成功举办是三方合作的第三年，此次课程紧随国际葡萄酒发展潮流，融合国际品酒师课程的全部内容，深入葡萄酒历史与文化、世界著名葡萄酒产区，着重教授学员品尝葡萄酒并辨别葡萄酒迥异的风格，有助于葡萄酒学院的学生掌握更多的职业技能，致力于培养中国优秀的品酒师及具有国际竞争能力的复合型人才。通过三方的合作，课堂上将葡萄酒理论与实践相结合，贯彻葡萄酒知识和文化优势互补的理念，将加速中国葡萄酒行业与国际接轨，为葡萄酒产业在中国的可持续发展奠定良好的基础。\r\n</p>', 'article_pic/1379124145.jpg', '1379124145', '1379124145', 4, NULL, 0, 3),
(30, '贺兰山赞助第一届中国葡萄酒盲品大赛', '由贺兰山葡萄酒赞助的第一届中国葡萄酒盲品大赛于7月14日在上海完美落下帷幕。此次大赛由酒斛网、红樽坊、红缇、尚9联合主办，作为一贯致力于推动国内葡萄酒文化发展的贺兰山葡萄酒，倾情赞助了本次具有行业纪念', '<p>\r\n	<span style="font-family:����;font-size:14px;line-height:26px;">由贺兰山葡萄酒赞助的第一届中国葡萄酒盲品大赛于7月14日在上海完美落下帷幕。此次大赛由酒斛网、红樽坊、红缇、尚9联合主办，作为一贯致力于推动国内葡萄酒文化发展的贺兰山葡萄酒，倾情赞助了本次具有行业纪念意义的比赛。此次盲品大赛旨在挖掘行业内外的品酒高手，共同推广葡萄酒文化，作为白金赞助商，贺兰山葡萄酒见证了此次大赛的成功举办。</span> \r\n</p>\r\n<p>\r\n	<span style="font-family:����;font-size:14px;line-height:26px;"></span> \r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	本次大赛云集了来自国内葡萄酒行业，高校与民间的各路高手，共计51组153人。同时还吸引了众多媒体和葡萄酒爱好者的热情观赛。大赛分初赛和复赛两轮，总共8款具有产地特征的葡萄酒。第一轮初赛的五道盲品题目结束后，仅有12组选手晋级复赛，最终，由EMW队夺得了本届大赛的冠军。\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　有趣的是，在第一轮比赛环节中，有许多选手把一支来自法国勃艮第的黑品乐葡萄酒，错猜成来自宁夏贺兰山东麓的黑品乐葡萄酒，这使我们看到中国宁夏贺兰山东麓这片富饶地葡萄酒产区已为越来越多爱酒人士所认可。\r\n</p>\r\n<div>\r\n	<br />\r\n</div>', 'article_pic/1379124438.jpg', '1379124174', '1379124438', 7, NULL, 0, 0),
(31, '姚明视察纳帕葡萄酒酒庄', '不久前为助阵魔兽霍华德加盟火箭，前火箭球星姚明重返休斯顿。随后姚明来到旧金山纳帕谷视察他在当地的酒庄。', '<p>\r\n	<span style="font-family:����;font-size:14px;line-height:26px;">不久前为助阵魔兽霍华德加盟火箭，前火箭球星姚明重返休斯顿。随后姚明来到旧金山纳帕谷视察他在当地的酒庄。姚明在两年前就开始了自己的葡萄酒业投资，在纳帕谷成立了葡萄酒公司，并拥有了自己的酒庄。出产的“姚家族”葡萄酒销量也非常的好，其中大多都是在中国国内销售，高端的产品价格为650美元，中端产品价格为150美元，近日还推出了主打低端市场，售价48美元的子品牌。</span>\r\n</p>\r\n<div>\r\n	<br />\r\n</div>', 'article_pic/1379124202.jpg', '1379124202', '1379124202', 4, NULL, 0, 6),
(32, '“品醉2013”论坛目标观众', '澳大利亚葡萄酒行业热烈欢迎世界各地的葡萄酒业内人士一起参加在阿德莱得举行的“品醉2013”论坛', '<p style="font-family:����;font-size:14px;">\r\n	澳大利亚葡萄酒行业热烈欢迎世界各地的葡萄酒业内人士一起参加在阿德莱得举行的“品醉2013”论坛，尤其是：\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　• 澳大利亚葡萄酒酿酒商\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　•国内外贸易商（酒吧会所专业人士和零售商、餐饮界人士和零售店） 以及葡萄酒进口商和分销商\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　•酒媒、生活方式和商务媒体\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　贸易商、进口商和分销商代表分别来自中国大陆、香港、新加坡、印度、日本、韩国、美国、加拿大、澳大利亚、英国、爱尔兰、欧洲大陆、中东和拉丁美洲等国家和地区。\r\n</p>', 'article_pic/1379124353.jpg', '1379124353', '1379124353', 6, NULL, 0, 0),
(33, '香槟酒瓶尺寸对香槟风格的影响', '一瓶半瓶装（375ML）的汝纳特非年份白中白香槟中竟然出现了陈年香槟所发展出的香气；而一瓶3L装的大瓶装香槟则出现了较年轻香槟的特质，散发出迷人的香气；标准瓶（750ML）中的香槟口感丰富，十分迷人；', '<p style="font-family:����;font-size:14px;">\r\n	上周一，古老的汝纳特香槟（Champagne Ruinart）酒庄通过盲品实验，证实了酒瓶大小对瓶中香槟的风格影响巨大。\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　在盲品过程中，一群葡萄酒作家对ISO品酒杯中装的6款香槟进行了评价。这6款香槟中有4款实际上是同一款香槟，只是它们装在不同尺寸的酒瓶中。\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　他们的评价结果是：一瓶半瓶装（375ML）的汝纳特非年份白中白香槟中竟然出现了陈年香槟所发展出的香气；而一瓶3L装的大瓶装香槟则出现了较年轻香槟的特质，散发出迷人的香气；标准瓶（750ML）中的香槟口感丰富，十分迷人；在1.5L装瓶中陈放的香槟口感最平衡。\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　在该酒庄公布结果之后的伦敦一场发布会午宴上，堡林爵香槟（Champagne Bollinger）呈上了该酒庄最新发布的酒款：2000年份堡林爵RD香槟（Bollinger RD）。此酒是用3L装的大瓶装瓶的，使用该瓶的目的是更好地保存香槟的新鲜口感。\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　堡林爵新任总酿酒师吉勒斯•迪斯科特（Gilles Descotes）说“2000年是个非常温暖的年份，我们认为该年出产的葡萄酒缺少一些新鲜感，不适合酿制新近除渣（RD，全称为Recently Disgorged）香槟，但使用大瓶后，一切都非常完美。大瓶能赋予香槟新鲜感和复杂感，而标准瓶却办不到的。”\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　同时，迪斯科特还强调了堡林爵新推出的一款1.5装的大酒瓶对香槟陈年的作用。该酒瓶该酒瓶底部较款，但它的颈部却非常狭窄，因此被戏称为“迷你型1.5L装大酒瓶”。\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　迪斯科特解释说此酒瓶的设计可减少进入瓶中的氧气，减缓葡萄酒发展的进程。\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　堡林爵香槟的英国进口商Mentzendorff 的总经理安德鲁•霍斯（Andrew Hawes）表示该瓶型对堡林爵非年份桃红葡萄酒影响最大。他说此瓶能赋予桃红香槟非常不一样的口感。\r\n</p>\r\n<div>\r\n	<br />\r\n</div>', 'article_pic/1379124389.jpg', '1379124389', '1379124389', 6, NULL, 0, 0),
(34, '实验研究：音乐对葡萄酒的影响', '相信您一定知道葡萄酒本身的温度会影响到酒的口感，但你听说过音乐也可以影响饮酒人对葡萄酒的感受吗？本文就将描述一项西方学者对葡萄酒口感与音乐之间的关系做出的实验研究和结论。', '<p style="font-family:����;font-size:14px;">\r\n	相信您一定知道葡萄酒本身的温度会影响到酒的口感，但你听说过音乐也可以影响饮酒人对葡萄酒的感受吗？本文就将描述一项西方学者对葡萄酒口感与音乐之间的关系做出的实验研究和结论。\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　有这样一位酿酒师，他说他时常为酒窖中的葡萄酒演奏爵士乐，以使它们保持愉悦的状态。这位酿酒师的名字叫布鲁诺·康斯利(Bruno de Conciliis)。布鲁诺为表现自己对爵士乐的投入，甚至把自己的签名改成了塞利姆(Selim)，而"Selim"正好是美国著名爵士乐演奏家迈尔斯·戴维斯(Miles Davis)英文名字的字母倒写。布鲁诺的葡萄酒来自意大利的著名产区卡帕尼亚(Campania)，所以一定会令人感到惊喜，但目前还真的不确定葡萄酒是否会因为酒窖周围吹响的纯净小号声而有所改善。\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　虽然音乐能使葡萄汁发酵更加活跃的推断令人难以置信，但音乐是否能影响到品酒人自己对葡萄酒的评鉴和理解还无法确定，要知道音乐非常容易渗透进我们的情感世界。\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　几年以前，时任英国爱丁堡(Edinburgh)瓦特大学(Heriot-Watt University)应用心理系主任的阿德里安·诺斯(Adrian North)就发表过对这一论题的相关实验报告。诺斯教授在智利的蒙特斯酒庄(Montes Wines)所做的调查中，就发现了葡萄酒的评鉴结果和饮用葡萄酒时所听音乐之间的关系。\r\n</p>', 'article_pic/1379124417.jpg', '1379124417', '1379124417', 7, NULL, 0, 0),
(35, '让微信做好营销', '', '<p style="text-align:left;">\r\n	<span style="background-color:#F7F7F7;color:#555555;font-family:宋体;line-height:1.5;">完善会所的责任，由服务中心这支以创意见长的团队来完成。</span> \r\n</p>\r\n<span style="color:#555555;font-family:宋体;background-color:#F7F7F7;">1空间设计：从会所生命周期出发，把资源、环境与健康作为整体考虑，研究空间因素的结构和功能关系，真正实现人与自然的和谐统一。</span><br />\r\n<br />\r\n<span style="color:#555555;font-family:宋体;background-color:#F7F7F7;">2微客服：让微信做好营销，平台的维护和创新是关键。互联网的无边界性优势通过微信获取用户和满足用户需求，电子商务只是他们其中的销售渠道，微营销的精准特点，主动添加关注的微信用户是喜欢我们的商品或者有购买需求的人，根据消费者的个人信息有效的了解消费者的个人购买习惯。创新与积累通过这些评判来提升自己的服务能力，在环节上进行最大效率优化，完善一整套产业服务格局。</span><br />\r\n<br />\r\n<span style="color:#555555;font-family:宋体;background-color:#F7F7F7;">3会所商品：经销商决定采购何种商品，未来将会由顾客全程参与到采购环节中，由用户共同决策来选择他们想要的产品。服务中心对产生的数据配合互联网大数据整合推送，使得资源利用最大化，建立互联网信任机制，将商品定价变得透明，降低消费者的信息获得成本，彻底的全球化信任问题会随着时间很好地建立。用户可以依靠平台上的主题会所解决所有商品的相互需求。致力于解决物流问题的公司自然更有优势。</span>', 'article_pic/1379125617.jpg', '1379125617', '1379324534', 3, NULL, 0, 6),
(37, '我心中的歌', '我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌', '我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌我心中的歌', 'article_pic/1379914385.jpg', '1379321096', '1379914385', 5, '', 0, 0),
(38, '发展规划汇编', '发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编', '发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编发展规划汇编', 'article_pic/1379914349.jpg', '1379321588', '1379914349', 5, '', 0, 1),
(39, '走进墙上标语历史', '走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史', '走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史走进墙上标语历史', 'article_pic/1379914308.jpg', '1379321595', '1379914308', 5, '', 0, 0),
(40, 'THE SPIR-T', 'THE SPIR-TTHE SPIR-TTHE SPIR-TTHE SPIR-T', 'THE SPIR-TTHE SPIR-TTHE SPIR-TTHE SPIR-TTHE SPIR-TTHE SPIR-TTHE SPIR-TTHE SPIR-TTHE SPIR-TTHE SPIR-TTHE SPIR-TTHE SPIR-TTHE SPIR-TTHE SPIR-TTHE SPIR-TTHE SPIR-TTHE SPIR-TTHE SPIR-TTHE SPIR-TTHE SPIR-T', 'article_pic/1379914262.jpg', '1379321603', '1379914262', 5, '', 0, 1),
(36, '古代文学选', '古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选', '古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选古代文学选', 'article_pic/1379914437.jpg', '1379320982', '1379914437', 5, '', 0, 1),
(41, 'istockphoto', 'istockphotoistockphotoistockphotoistockphotoistockphoto', '<p>\r\n	istockphotoistockphotoistockphotoistockphotoistockphotoistockphoto\r\n</p>\r\n<p>\r\n	istockphotoistockphotoistockphotoistockphotoistockphotoistockphotoistockphotoistockphotoistockphoto\r\n</p>\r\n<p>\r\n	stockphotoistockphotoistockphotoistockphotoistockphoto\r\n</p>\r\n<p>\r\n	<p>\r\n		istockphotoistockphotoistockphotoistockphotoistockphotoistockphoto\r\n	</p>\r\n	<p>\r\n		istockphotoistockphotoistockphotoistockphotoistockphotoistockphotoistockphotoistockphotoistockphoto\r\n	</p>\r\n	<p>\r\n		stockphotoistockphotoistockphotoistockphotoistockphoto\r\n	</p>\r\n</p>', 'article_pic/1379914211.jpg', '1379321611', '1379919795', 5, '', 0, 3),
(42, 'LITTLE SLEEP', 'LITTLE SLEEPLITTLE SLEEPLITTLE SLEEPLITTLE SLEEP', 'LITTLE SLEEPLITTLE SLEEPLITTLE SLEEPLITTLE SLEEPLITTLE SLEEPLITTLE SLEEPLITTLE SLEEPLITTLE SLEEPLITTLE SLEEPLITTLE SLEEPLITTLE SLEEPLITTLE SLEEPLITTLE SLEEPLITTLE SLEEPLITTLE SLEEPLITTLE SLEEPLITTLE SLEEP', 'article_pic/1379914171.jpg', '1379321618', '1379914171', 5, '', 0, 1),
(43, 'SYLVIA PLATH', 'SYLVIA PLATHSYLVIA PLATHSYLVIA PLATHSYLVIA PLATHSYLVIA PLATH', 'SYLVIA PLATHSYLVIA PLATHSYLVIA PLATHSYLVIA PLATHSYLVIA PLATHSYLVIA PLATHSYLVIA PLATHSYLVIA PLATHSYLVIA PLATHSYLVIA PLATHSYLVIA PLATH<span>PLATHSYLVIA PLATH<span>PLATHSYLVIA PLATH<span>PLATHSYLVIA PLATH<span>PLATHSYLVIA PLATH<span>PLATHSYLVIA PLATH<span>PLATHSYLVIA PLATH<span>PLATHSYLVIA PLATH<span>PLATHSYLVIA PLATH<span>PLATHSYLVIA PLATH</span></span></span></span></span></span></span></span></span>', 'article_pic/1379914129.jpg', '1379321626', '1379915084', 5, '', 0, 4),
(49, '微信', '微信，超过3亿人使用，能够通过手机网络给好友发送语音、文字消息、表情、图片和视频，还可以分享照片到朋友圈。', '<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">微信，超过3亿人使用，能够通过手机网络给好友发送语音、文字消息、表情、图片和视频，还可以分享照片到朋友圈。通过摇一摇、查看附近的人，你可以认识新的朋友。使用扫一扫，你可以扫描二维码、条码、图书和街景。你还可以在游戏中心玩游戏，使用微信支付，与公众号互动…… 微信在 iPhone、Android、Symbian、Windows Phone、BlackBerry 等手机平台上都可以使用，并提供有多种语言界面。</span>', 'article_pic/1379389675.png', '1379389675', '1379469382', 12, 'http://as.baidu.com/a?pre=web_am_header&f=web_alad_5%40next', 0, 0),
(50, '新浪微博', '基于Android平台的新浪微博手机客户端，集阅读、发布、评论、转发、私信、关注等主要功能为一体，本地相机即拍即传，随时随地同朋友分享身边的新鲜事。 喜欢微博的你，赶快装上一个，开始真正的随时随地“微博”生活吧。', '<table style="font-size:12px;width:590px;color:#333333;font-family:arial, verdana, sans-serif;background-color:#FFFFFF;">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				<p>\r\n					<span style="color:#666666;font-family:arial, verdana, sans-serif;line-height:19px;">全新的微博如今更流畅、更稳定！还有全新的活动系统，更多惊喜等你发现。</span> \r\n				</p>\r\n				<p>\r\n					大小：<span class="params-size">14.7MB</span> \r\n				</p>\r\n				<p>\r\n					版本：<span class="params-vname">4.0.0</span> \r\n				</p>\r\n				<p>\r\n					下载次数：<span class="params-download-num">5000万+</span> \r\n				</p>\r\n				<p>\r\n					系统要求：<span class="params-platform">Android1.6及以上</span> \r\n				</p>\r\n				<p>\r\n					更新时间：<span class="params-updatetime">2013-08-23</span> \r\n				</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<br />', 'article_pic/1379389851.png', '1379389851', '1379469374', 12, 'http://as.baidu.com/a?pre=web_am_header&f=web_alad_5%40next', 0, 0),
(51, 'UC浏览器', '新版优化首页操作体验，提升浏览器整体使用流畅度。针对网址和软件实施云安全检测，为你提供安全的上网环境。', '<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">UC浏览器是一款全球领先的智能移动浏览器，拥有独创的U3内核和云端技术，完美地支持HTML5应用，具有智能、极速、安全，易扩展等特性，让您在阅资讯、读小说、看视频、上微博、玩游戏、网上购物等都能享受最流畅的移动互联网体验。 现在，使用UC浏览器可以观看优酷、搜狐视频、爱奇艺等数十家视频网站的海量资源，不论是电影、电视剧还是综艺节目，都可以一手在握。UC浏览器首家支持了“离线缓存”功能，方便在没有网络时观看视频。UC浏览器还支持了快播和百度视频插件，可以播放很多特殊视频源。用UC浏览器看视频，想怎么看，就怎么看！ UC浏览器插件系统全新上线，让你的浏览器精简但不失强大。支持自定义安装插件，个性需求个性满足。你可以“找身边”的真爱，如果“截图涂鸦”不足以表达感情，也可以“语音”告诉UC浏览器，让他帮你“翻译”一下！</span>', 'article_pic/1379389915.png', '1379389915', '1389752043', 12, 'http://www.baidu.com', 0, 0),
(52, '我查查', '查什么？想查什么查什么，查查比比价，查快递，照一照，全知道！', '<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">1.傻瓜式操作，简单易使用，老爸老妈也能轻易上手，这不仅仅是年轻人的专利。</span><br />\r\n<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">2.一维码、二维码、快递单号，轻松一照就知道，我查查无码不识。</span><br />\r\n<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">3.超市价格、网商价格、促销价格，掏钱之前比一比，海量数据，一应俱全。</span><br />\r\n<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">4.曝光栏红黑榜，查询质量监督部门最新抽检结果，将不合格产品拒之门外。</span><br />\r\n<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">5.不再头疼脚痛的盲目逛街，不再“内牛满面”错过特惠打折，我逛逛&amp;超市促销让你稳、准、狠的实惠买名牌！</span><br />\r\n<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">6.摇一摇，收听商品评论、真假防伪，同时支持语音上传，比价格享优惠之余，也需要自娱自乐一下。</span>', 'article_pic/1379389984.png', '1379389984', '1379469512', 14, 'http://as.baidu.com/a?pre=web_am_header&f=web_alad_5%40next', 0, 0),
(53, '中国万年历', '支持云同步，有农历、天气，拥有独特直观的时光轴记事，体积小巧，符合国人使用习惯。', '<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">云日历：公历、农历、天干地支老黄历，历历在目，日视图，周视图，月视图，图文并茂；无缝同步系统日历，自定义日历、exchange日历、google 日历。 云提醒：法定节假日安排、生日(显示生肖和星座)、纪念日、朋友约会日、倒计时……，给你的生活提个醒。</span>', 'article_pic/1379390055.png', '1379390055', '1379469503', 14, 'http://as.baidu.com/a?pre=web_am_header&f=web_alad_5%40next', 0, 0),
(54, '百度新闻', '可根据兴趣选择内容类别，涵盖了新闻、图片、笑话、博客等8000+种内容来源！', '<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">1. 海量内容，精准推荐 聚合8000+内容来源，借助独有的推荐引擎技术，投你所好，推荐最感兴趣的个性化优质内容。</span><br />\r\n<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">2. 简单易用，打开即“悦” 简单易操作，支持一键分享到微博、邮件、短信。</span><br />\r\n<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">3. 界面精美，视觉惊艳 极致简洁的界面，人性化的交互体验，丰富的美女和资讯图片，处处都是视觉的盛宴。</span><br />\r\n<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">4. 压缩传输，节省流量 文字和图片高比例压缩传输，节省近四分之三的流量，支持离线阅读，为你省钱省时间。</span>', 'article_pic/1379390121.png', '1379390121', '1379390121', 13, 'http://as.baidu.com/a?pre=web_am_header&f=web_alad_5%40next', 0, 0),
(55, '爱读掌阅', '爱读掌阅是一款专注于手机阅读领域的经典阅读软件。支持EBK3/TXT/UMD/EPUB/CHM/PDF全主流阅读格式。', '<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">功能强大，个性时尚，界面简约，与各大出版社进行深度战略合作，拥有广阔图书资源。 从软件发布伊始，团队与用户一路相伴，不断的调整及淬炼，使iReader读书逐渐蜕变成拥有绝佳用户口碑的阅读神器，令用户在阅读体验中不断获得至尊级殿堂服务。今后我们将继续致力于缔造正版阅读享受，撷精华退糟粕，竭诚提供贴心服务，为用户点亮高品位文化生活。爱读书，读好书，就用iReader！</span>', 'article_pic/1379390187.png', '1379390187', '1379390187', 13, 'http://as.baidu.com/a?pre=web_am_header&f=web_alad_5%40next', 0, 0),
(56, '搜狐新闻', '享受精编报纸的服务天天有, 了解最热的实时新闻不分时间和地方, 集要闻·体育·娱乐等图文并茂于一体。', '<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">搜狐新闻客户端是现在最流行的新闻类app，是央视新闻独家合作伙伴、第二季《中国好声音》战略合作伙伴。海量媒体账号等您关注，免费独家资源任您阅读。</span><br />\r\n<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">每天上班、下班、睡前用手机要做的三件事：刷微博、聊微信、看搜狐新闻客户端。</span>', 'article_pic/1379390252.png', '1379390252', '1379390252', 13, 'http://as.baidu.com/a?pre=web_am_header&f=web_alad_5%40next', 0, 0),
(57, '今日头条', '真正社交化的资讯阅读应用。便捷地看到你最感兴趣和最热门的资讯，和朋友互动，发表对世界的看法吧。', '<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">你关心的，才是头条！《今日头条》会聪明地分析您的兴趣爱好，理解您的阅读行为，自动为您推荐喜欢的内容，并且越用越懂你。具备语音播新闻的重磅功能，听新闻，不费流量！</span><br />\r\n<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">媒体及名人推荐： 36Kr ——“区别于一般的阅读应用，今日头条无需用户做任何选择，即可快速展现给用户最感兴趣的资讯。” 搜狗CEO王小川——“今日头条，是一款真正的好产品，不仅做到了个性化，而且还保证了可读性。</span>', 'article_pic/1379390309.png', '1379390309', '1379390309', 13, 'http://as.baidu.com/a?pre=web_am_header&f=web_alad_5%40next', 0, 0),
(58, '米心书城', '米心书城是一款精品手机电子阅读应用，用户可以免费下载和使用。它是一个可随身携带的电子书店，海量图书可供用户免费下载。米心书城致力于提供轻松舒适的阅读体验。', '<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">特色功能：</span><br />\r\n<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">1、高品质的用户体验，极速加载。</span><br />\r\n<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">2、支持WIFI自动下载图书，离线阅读。</span><br />\r\n<span style="color:#666666;font-family:arial, verdana, sans-serif;font-size:14px;line-height:22px;background-color:#FFFFFF;">3、在线云听书、在线云书架、云收藏等</span>', 'article_pic/1379390389.png', '1379390389', '1379469407', 13, 'http://as.baidu.com/a?pre=web_am_header&f=web_alad_5%40next', 0, 0);
INSERT INTO `yk_article` (`aid`, `title`, `shortdesc`, `content`, `picture`, `createtime`, `updatetime`, `cat_id`, `url`, `review_number`, `praise_number`) VALUES
(59, '诚招诚征各地区木工机械设备代理加盟', '', '<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	合同期限：2（年）	加盟商总数：900（家）	特许经营时间：2（年）\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	保证金额：50000（元）	基本投资额：10-50万（元）	发展模式：经销,区域代理,单店特许,区域开发\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	品牌：烟台福鼎木工机械	品牌发源地：山东烟台	项目区域要求：全国\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	加盟费：50000（元）	预计回报周期：1（年）	预计回报率：20（%）\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	经营模式：经销,代理,特许,合作\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	<div>\r\n		联 系 &nbsp;人：许培虎 先生 （总经理）\r\n	</div>\r\n	<div>\r\n		电 &nbsp; &nbsp; &nbsp;话：86 0535 4709333\r\n	</div>\r\n	<div>\r\n		移动电话： 15106566666\r\n	</div>\r\n	<div>\r\n		传 &nbsp; &nbsp; &nbsp;真：86 0535 4709111\r\n	</div>\r\n	<div>\r\n		地 &nbsp; &nbsp; &nbsp;址：中国 山东 烟台市牟平区 牟平开发区文峰路9号\r\n	</div>\r\n</div>', 'article_pic/1379407387.jpg', '1379407387', '1379407387', 3, NULL, 0, 7),
(60, '食品加工及包装机械展览会即将在南昌召开', '', '<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	由国家商务部和江西省政府共同主办，南昌市人民政府、商务部流通产业促进中心、江西省商务厅、江西省农业厅共同承办的2013第六届中国绿色食品博览会于2013年11月22-25日继续在南昌国际展览中心举办，展会专门设置食品加工及包装机械专区：本届绿色食博会展示面积近5万平方米，设2300多个个国际标准展位，规模创下亚洲之最，在全世界范围内也名列前茅。\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　据悉，此次中国绿色食品博览会分为5个室内展馆，分别为：名优特产品特装展示区、茶文化酒文化展区、食品加工及包装机械展区、台湾食品及国际食品展区、各省市代表团组团参展展区、江西省各设区市组团参展展区等。\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　据了解，此次中国绿色食博会有来自四川、广西、广东、云南、甘肃、宁夏、福建、贵阳、黑龙江、吉林、内蒙古、天津、上海、宁波、长春、合肥、广州、兰州等36个省、市、自治州（区）及港澳台的企业组团参展；其中有来自美国、欧盟、澳大利亚、越南、泰国、缅甸、日本、韩国、俄罗斯、斯里兰卡、印度等国外的展团参展；参展企业中省外企业占近50%，境外企业占20%。另外，将有包括沃尔玛、麦德龙、大连大商、中国连锁经营协会及北京商贸专业采购团等国际知名采购连锁企业在内的3500家超大型企业名到会采购。\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　据统计，在2012第五届中国绿色食品博览会期间，大小10000多个类别的展品琳琅满目，前来参观、洽谈、订货的专业采购商达3.8万余人，参观人数21.6万人次。上届博览会效果显著，取得了丰硕成果。展会现场交易金额达2.29亿元，意向合同金额达38.10亿元，总交易金额达40.39亿元，相比上届增长率9.77%。其中，农超对接签约仪式上共签订了5亿元的合同订单。此次第五届绿色食品博览会将在上届基础上，加大招商力度，和宣传邀请力度，另外将开展更多的商贸洽谈活动，如：\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　（一）开幕式暨欢迎晚宴\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　时间：2013年11月21日晚\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　地点：南昌前湖宾馆宴会大厅\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　（二）连锁企业采购信息发布会及洽谈会\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　时间：2013年11月22日10:00&nbsp;\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　地点：南昌国际展览中心多功能厅\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　（三）江西省三大名品节（赣南脐橙节、南丰蜜桔节、鄱阳湖螃蟹节）\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　时间：2013年11月22日10:00-11:00\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　地点：南昌国际展览中心\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　（四）全国绿色食品专场推介会。\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　时间：2013年11月23日9:30\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　地点：南昌国际展览中心多功能厅\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　（五）农超对接签约仪式\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　时间：2013年11月23日14:30\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　地点：南昌国际展览中心多功能厅或一号贵宾厅\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　（六）博览会奖项活动\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　相信在商务部，江西省政府的主持，各方面单位及组委会的精心组织下，此届展会将再创佳绩。热诚欢迎国内外的绿色食品行业精名品产品，知名企业及贸易团体到会交易，中部崛起，魅力江西，商机无限。\r\n</div>', 'article_pic/1379407429.jpg', '1379407429', '1379407429', 3, NULL, 0, 11),
(61, '2013第六届中国绿色食品博览会将开创绿色食品新纪元', '', '<span style="font-size:14px;color:#333333;font-family:Arial, Helvetica, sans-serif;line-height:30px;background-color:#FFFFFF;">由国家商务部和江西省政府共同主办，南昌市人民政府、商务部流通产业促进中心、江西省商务厅、江西省农业厅共同承办的2013</span><span style="font-size:14px;color:#333333;font-family:Arial, Helvetica, sans-serif;line-height:30px;background-color:#FFFFFF;">于2013年11月22-25日继续在南昌国际展览中心举办，本届绿色食博会展示面积近5万平方米，设2300多个个国际标准展位，分为5个室内展馆，分别为：名优特产品特装展示区、茶文化食品包装机械及酒类展区、台湾食品及国际食品展区、各省市代表团组团参展展区、江西省各设区市组团参展展区等。</span><br />\r\n<span style="font-size:14px;color:#333333;font-family:Arial, Helvetica, sans-serif;line-height:30px;background-color:#FFFFFF;">　　据了解，此次中国绿色食博会有来自四川、广西、广东、云南、甘肃、宁夏、福建、贵阳、黑龙江、吉林、内蒙古、天津、上海、宁波、长春、合肥、广州、兰州等18个省、市组团参展的2000多家食品企业组团参展。其中有来自台湾、香港、欧盟、越南、泰国、缅甸、日本、韩国、俄罗斯、斯里兰卡、印度等国外的展团参展；参展企业中省外企业占近50%，境外企业占20%。另外，将有包括沃尔玛、麦德龙、大连大商、中国连锁经营协会及北京商贸专业采购团等国际知名采购连锁企业在内的3500家超大型企业名到会采购。</span><br />\r\n<span style="font-size:14px;color:#333333;font-family:Arial, Helvetica, sans-serif;line-height:30px;background-color:#FFFFFF;">　　据统计，在第四届中国绿色食品博览会期间，大小10000多个类别的展品琳琅满目，前来参观、洽谈、订货的专业采购商达3.8万余人，参观人数21.6万人次。本届博览会效果显著，取得了丰硕成果。展会现场交易金额达2.29亿元，意向合同金额达38.10亿元，总交易金额达40.39亿元，相比上届增长率9.77%。其中，农超对接签约仪式上共签订了5亿元的合同订单。此次第五届绿色食品博览会将在上届基础上，加大招商力度，和宣传邀请力度，另外将开展更多的商贸洽谈活动，如：</span><br />\r\n<span style="font-size:14px;color:#333333;font-family:Arial, Helvetica, sans-serif;line-height:30px;background-color:#FFFFFF;">　　（一）博览会开幕式及欢迎晚宴&nbsp;</span><br />\r\n<span style="font-size:14px;color:#333333;font-family:Arial, Helvetica, sans-serif;line-height:30px;background-color:#FFFFFF;">　　（二）连锁企业采购信息发布会及洽谈会</span><br />\r\n<span style="font-size:14px;color:#333333;font-family:Arial, Helvetica, sans-serif;line-height:30px;background-color:#FFFFFF;">　　（三）一湖清水•鄱阳湖螃蟹节&nbsp;&nbsp;</span><br />\r\n<span style="font-size:14px;color:#333333;font-family:Arial, Helvetica, sans-serif;line-height:30px;background-color:#FFFFFF;">　　（四）绿色食品与电子商务高峰论坛</span><br />\r\n<span style="font-size:14px;color:#333333;font-family:Arial, Helvetica, sans-serif;line-height:30px;background-color:#FFFFFF;">　　（五）绿色食博览会购销推介会&nbsp;</span><br />\r\n<span style="font-size:14px;color:#333333;font-family:Arial, Helvetica, sans-serif;line-height:30px;background-color:#FFFFFF;">　　（六）农超对接签约仪式</span><br />\r\n<span style="font-size:14px;color:#333333;font-family:Arial, Helvetica, sans-serif;line-height:30px;background-color:#FFFFFF;">　　（七）绿色食博览会奖励活动&nbsp;&nbsp;&nbsp;</span><br />\r\n<span style="font-size:14px;color:#333333;font-family:Arial, Helvetica, sans-serif;line-height:30px;background-color:#FFFFFF;">　　（八）鄱阳湖特色游</span><br />\r\n<span style="font-size:14px;color:#333333;font-family:Arial, Helvetica, sans-serif;line-height:30px;background-color:#FFFFFF;">　　相信在商务部，江西省政府的主持，各方面单位及组委会的精心组织下，此届展会将再创佳绩。热诚欢迎国内外的绿色食品行业精名品产品，知名企业及贸易团体到会交易，魅力江西，商机无限。</span>', 'article_pic/1379407472.jpg', '1379407472', '1379991255', 3, '', 0, 9),
(62, '人造砂岩技术 砂岩浮雕加盟 招商代理砂岩浮雕制作机械', '', '<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	装机容量：	7（kw）	激振频率：	2800（次/分）\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	加工定制：	是	类型：	石材机械\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	成型周期：	6-9（秒）	振动频率：	2800（hz）\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	型号：	HX168	别名：	砂岩浮雕背景墙生产制造机械设备\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	主振形式：	震动	最大压力：	8（KN）\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	用途：	制作砂岩浮雕艺术背景墙砖	总功率：	7（w）\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	品牌：	和鑫	整机重量：	1（t）\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	产品性能：以砂岩、树脂为主要原料，通过专业自动艺术浮雕机械设备模压成型，外观漂亮、浮雕纹理细致凸显、规格统一、平整不翘角、坚固耐用。\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	&nbsp; &nbsp; &nbsp; &nbsp; 工作性能：机电一体化，全自动按钮、数据控制，运行稳定；流水线生产，生产速度可调，每分钟可生产4－6 块，省时、省事、省心、省工。\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	&nbsp; &nbsp; &nbsp; &nbsp; 设备优势：投资适中、操作简单、场地要求不大、生产人员2-3人、生产效益高、有效降低生产成本、为厂家提高了市场竞争力。\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	&nbsp; &nbsp; &nbsp; &nbsp; 服务优势：上门安装设备，上门培训生产工人，长期技术指导，支持产品升级。\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	&nbsp; &nbsp; &nbsp; &nbsp; 投资规模：系列设备投资数万元至十来万元不等，根据投资者实际情况，选择相应的投资设备方案，是中小创业者的理想投资项目。\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;市场需求：砂岩艺术浮雕拼板是近期风行全国装饰材料市场的高档新兴产品，是替代以往墙纸、墙绘、大理石等的趋势产品。任一单个城市或县级市场容量达数百万价值之多。\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	产品优点：\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	&nbsp; 产品全国独家生产与众不同：全自动生产流水线包括自动砂岩拼板浮雕机、全自动定量供料机、斗式自动上料机、自控温脱模机和全自动微电脑控制柜，共5台设备组成，售价129800元/套，4人班产2800块，现在请工人大多数是按生产效率算工资，多劳多得，生产不了多少产品就拿不了多少钱，给多了你不愿意，给少了工人不愿意，按月付工资吃大锅饭，工人又不好管理。所以买台好机器很重要。\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	该设备价值远远超越它的价格，因其简易的操作，先进的成型方式，卓越的省电功能和独特的生产工艺，为你短时间内收回成本奠定了基础，加之我公司完善的售后服务体系解除了你的后顾之忧。\r\n</div>', 'article_pic/1379407539.jpg', '1379407539', '1379407539', 3, NULL, 0, 16),
(63, '2013第二届长城葡萄酒杯 RVF CHINA品酒师大赛火热开赛', '由中国食品有限公司和财讯传媒集团旗下《葡萄酒评论》杂志共同举办的2013第二届长城葡萄酒杯RVFCHINA品酒师大赛初赛于7月27日10点整在北京华腾美居酒店正式拉开战幕。经过3个月的前期宣传招募，共', '<p>\r\n	<span style="font-family:����;font-size:14px;line-height:26px;">由中国食品有限公司和财讯传媒集团旗下《葡萄酒评论》杂志共同举办的2013第二届长城葡萄酒杯RVFCHINA品酒师大赛初赛于7月27日10点整在北京华腾美居酒店正式拉开战幕。经过3个月的前期宣传招募，共有400多位来自葡萄酒行业内外的精英们踏上了品酒师大赛的精彩之旅。</span>\r\n</p>\r\n<p>\r\n	<span style="font-family:����;font-size:14px;line-height:26px;"></span>\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	初赛当日，来自全国各地及国外的葡萄酒专业人员或爱好者们状态表现良好，数十位业内权威专家齐集一堂，共同见证了这一葡萄酒行业重要盛世。专家们表示，长城葡萄酒杯RVFCHINA品酒师大赛为行业内注入了一股新鲜血液，为选手们搭建了一个宽广的专业平台，从获得国家品酒师一、二、三级专业证书到拥有巴黎葡萄酒学院证书，最后站上世界品酒师大赛的国际舞台，大赛在推动中国葡萄酒行业全面健康国际化发展的道路上不遗余力，是行业内不可多得的重要赛事。\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　大赛理论考试从上午十点正式开始，经过一个半小时的基础品酒师理论知识的全面考察，使选手们对自己的理论水平有了准确的定位。接下来进行的是长达四个小时的实操考核，选手们深刻体会到了成为一名合格的品酒师所需具备的基本实战技能。考核共分6个轮次进行，每个轮次品评时间从15分钟到30分钟不等，每位选手在每个轮次对5个酒杯中的溶液成分阈值或酿酒葡萄品种进行品评鉴别。在阈值考核部分主要包括味觉阈值测定、香气浓度鉴别、糖度排序、酸度排序等；在酿酒葡萄品种品评鉴别中，需要选手能够全面熟练认知常见酿酒葡萄的特性，进而准确标出五个酒杯中的酿酒葡萄品种。\r\n</p>\r\n<div>\r\n	<br />\r\n</div>', 'article_pic/1379919258.jpg', '1379919258', '1379919258', 15, '', 0, 0),
(64, '2014年世界葡萄大会将在北京延庆县举办', '明年7月29日至8月2日，世界葡萄大会将首次走进亚洲，在北京延庆县举办。昨天（29日），延庆县举行了世葡会倒计时一周年新闻发布会，发布了大会会标和主题口号。', '<p style="font-family:����;font-size:14px;">\r\n	明年7月29日至8月2日，世界葡萄大会将首次走进亚洲，在北京延庆县举办。昨天（29日），延庆县举行了世葡会倒计时一周年新闻发布会，发布了大会会标和主题口号。与往届不同，本届大会突破了单一的学术会议内容，增加了葡萄酒博览会、葡萄酒品鉴大赛、产经论坛等内容。\r\n</p>\r\n<p style="font-family:����;font-size:14px;">\r\n	　　昨天的新闻发布会搬到了室外，在主会场酒店所在地的草坪上举行。大会指挥部发布了大会会标和主题口号，并启动了主题歌和吉祥物的征集活动。“相约长城，品味自然”被确定为大会主题口号，会标是由一条由绿变紫色的丝带，缠绕出长城、葡萄、中国结等象征图案，表达了“分享、交流、合作”的理念与发展前景。\r\n</p>', 'article_pic/1379919310.jpg', '1379919310', '1379919310', 15, '', 0, 0),
(65, '食品加工及包装机械展览会即将在南昌召开', '', '<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	由国家商务部和江西省政府共同主办，南昌市人民政府、商务部流通产业促进中心、江西省商务厅、江西省农业厅共同承办的2013第六届中国绿色食品博览会于2013年11月22-25日继续在南昌国际展览中心举办，展会专门设置食品加工及包装机械专区：本届绿色食博会展示面积近5万平方米，设2300多个个国际标准展位，规模创下亚洲之最，在全世界范围内也名列前茅。\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　据悉，此次中国绿色食品博览会分为5个室内展馆，分别为：名优特产品特装展示区、茶文化酒文化展区、食品加工及包装机械展区、台湾食品及国际食品展区、各省市代表团组团参展展区、江西省各设区市组团参展展区等。\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　据了解，此次中国绿色食博会有来自四川、广西、广东、云南、甘肃、宁夏、福建、贵阳、黑龙江、吉林、内蒙古、天津、上海、宁波、长春、合肥、广州、兰州等36个省、市、自治州（区）及港澳台的企业组团参展；其中有来自美国、欧盟、澳大利亚、越南、泰国、缅甸、日本、韩国、俄罗斯、斯里兰卡、印度等国外的展团参展；参展企业中省外企业占近50%，境外企业占20%。另外，将有包括沃尔玛、麦德龙、大连大商、中国连锁经营协会及北京商贸专业采购团等国际知名采购连锁企业在内的3500家超大型企业名到会采购。\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　据统计，在2012第五届中国绿色食品博览会期间，大小10000多个类别的展品琳琅满目，前来参观、洽谈、订货的专业采购商达3.8万余人，参观人数21.6万人次。上届博览会效果显著，取得了丰硕成果。展会现场交易金额达2.29亿元，意向合同金额达38.10亿元，总交易金额达40.39亿元，相比上届增长率9.77%。其中，农超对接签约仪式上共签订了5亿元的合同订单。此次第五届绿色食品博览会将在上届基础上，加大招商力度，和宣传邀请力度，另外将开展更多的商贸洽谈活动，如：\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　（一）开幕式暨欢迎晚宴\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　时间：2013年11月21日晚\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　地点：南昌前湖宾馆宴会大厅\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　（二）连锁企业采购信息发布会及洽谈会\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　时间：2013年11月22日10:00&nbsp;\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　地点：南昌国际展览中心多功能厅\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　（三）江西省三大名品节（赣南脐橙节、南丰蜜桔节、鄱阳湖螃蟹节）\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　时间：2013年11月22日10:00-11:00\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　地点：南昌国际展览中心\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　（四）全国绿色食品专场推介会。\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　时间：2013年11月23日9:30\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　地点：南昌国际展览中心多功能厅\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　（五）农超对接签约仪式\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　时间：2013年11月23日14:30\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　地点：南昌国际展览中心多功能厅或一号贵宾厅\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　（六）博览会奖项活动\r\n</div>\r\n<div style="font-family:Tahoma, ''Microsoft Yahei'', Simsun;font-size:14px;background-color:#FFFFFF;">\r\n	　　相信在商务部，江西省政府的主持，各方面单位及组委会的精心组织下，此届展会将再创佳绩。热诚欢迎国内外的绿色食品行业精名品产品，知名企业及贸易团体到会交易，中部崛起，魅力江西，商机无限。\r\n</div>', 'article_pic/1379919360.jpg', '1379919360', '1379919360', 15, '', 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `yk_article_category`
--
-- 创建时间: 2014 年 01 月 08 日 15:22
-- 最后更新: 2014 年 01 月 08 日 15:22
--

CREATE TABLE IF NOT EXISTS `yk_article_category` (
  `id` int(12) unsigned NOT NULL auto_increment COMMENT '栏目ID',
  `name` varchar(50) NOT NULL COMMENT '栏目名称',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- 转存表中的数据 `yk_article_category`
--

INSERT INTO `yk_article_category` (`id`, `name`) VALUES
(1, '上滑图片'),
(12, '荐-最新推荐'),
(3, '信息-发现'),
(4, '信息-关联'),
(5, '多元服务-设计'),
(6, '多元服务-体验'),
(7, '多元服务-管家'),
(8, '心灵花园'),
(13, '荐-精品阅读'),
(14, '荐-生活必备'),
(15, '多元服务-会员');

-- --------------------------------------------------------

--
-- 表的结构 `yk_club`
--
-- 创建时间: 2014 年 01 月 08 日 15:22
-- 最后更新: 2014 年 01 月 08 日 15:22
--

CREATE TABLE IF NOT EXISTS `yk_club` (
  `club_id` int(12) unsigned NOT NULL auto_increment COMMENT '主题会所ID',
  `club_name` varchar(20) NOT NULL COMMENT '会所名称',
  `club_manager` varchar(50) NOT NULL COMMENT '会所负责人',
  `club_pic` varchar(500) NOT NULL COMMENT '会所图片',
  `create_time` date NOT NULL COMMENT '添加时间',
  `is_show` int(1) NOT NULL default '0' COMMENT '是否显示模块',
  `manager_phone` varchar(20) NOT NULL COMMENT '负责人电话',
  `club_content` text NOT NULL COMMENT '会所简介',
  PRIMARY KEY  (`club_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- 转存表中的数据 `yk_club`
--

INSERT INTO `yk_club` (`club_id`, `club_name`, `club_manager`, `club_pic`, `create_time`, `is_show`, `manager_phone`, `club_content`) VALUES
(1, '主题会所01', 'wx', 'club_pic/default/default.png', '2013-09-22', 1, '123456', '<span>会所描述</span><span>会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述<span>会所描述</span><span>会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述<span>会所描述</span><span>会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述</span></span></span>'),
(2, '主题会所02', 'XXX', 'club_pic/default/default.png', '2013-09-22', 1, '', '<span>会所描述</span><span>会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述<span>会所描述</span><span>会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述会所描述</span></span>'),
(3, '主题会所03', 'XXX', 'club_pic/default/default.png', '2013-09-22', 1, '', '会所描述<span>会所描述<span>会所描述<span>会所描述<span>会所描述<span>会所描述<span>会所描述<span>会所描述<span>会所描述<span>会所描述<span>会所描述<span>会所描述<span>会所描述</span></span></span></span></span></span></span></span></span></span></span></span>'),
(4, '主题会所04', 'XXX', 'club_pic/default/default.png', '2013-09-23', 1, '', '主题会所04主题会所04主题会所04主题会所04主题会所04主题会所04主题会所04主题会所04主题会所04主题会所04主题会所04主题会所04主题会所04'),
(5, '主题会所05', 'XXX', 'club_pic/default/default.png', '2013-09-23', 0, '', '主题会所05主题会所05主题会所05主题会所05主题会所05主题会所05主题会所05主题会所05主题会所05主题会所05主题会所05主题会所05主题会所05主题会所05主题会所05主题会所05主题会所05主题会所05主题会所05主题会所05主题会所05主题会所05主题会所05主题会所05'),
(6, '主题会所06', 'XXX', 'club_pic/default/default.png', '2013-09-23', 1, '', '主题会所06主题会所06主题会所06主题会所06主题会所06主题会所06主题会所06主题会所06主题会所06主题会所06主题会所06主题会所06主题会所06主题会所06主题会所06主题会所06主题会所06主题会所06主题会所06'),
(7, '主题会所07', 'XXX', 'club_pic/default/default.png', '2013-09-23', 1, '', '主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07主题会所07'),
(8, '主题会所08', 'XXX', 'club_pic/default/default.png', '2013-09-23', 1, '', '主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08主题会所08'),
(9, '南亚大厦', '云库', 'club_pic/default/default.png', '2013-10-22', 0, '123456789', '南亚大厦南亚大厦南亚大厦南亚大厦');

-- --------------------------------------------------------

--
-- 表的结构 `yk_collection`
--
-- 创建时间: 2014 年 01 月 08 日 15:22
-- 最后更新: 2014 年 01 月 08 日 15:22
--

CREATE TABLE IF NOT EXISTS `yk_collection` (
  `id` int(12) unsigned NOT NULL auto_increment COMMENT 'ID',
  `user_id` int(12) NOT NULL COMMENT '用户ID',
  `product_id` int(12) NOT NULL COMMENT '商品ID',
  `collect_time` date NOT NULL COMMENT '收藏时间',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `yk_collection`
--


-- --------------------------------------------------------

--
-- 表的结构 `yk_comment`
--
-- 创建时间: 2014 年 01 月 08 日 15:22
-- 最后更新: 2014 年 01 月 15 日 00:47
--

CREATE TABLE IF NOT EXISTS `yk_comment` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `tid` int(10) default NULL COMMENT '贴子id',
  `uid` int(10) NOT NULL COMMENT '回复者',
  `content` varchar(255) NOT NULL,
  `createtime` datetime NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=149 ;

--
-- 转存表中的数据 `yk_comment`
--

INSERT INTO `yk_comment` (`id`, `tid`, `uid`, `content`, `createtime`) VALUES
(142, 23, 38, '玫琳凯喽', '2013-12-04 09:42:22'),
(143, 25, 38, '世界旅游组', '2013-12-04 09:43:15'),
(144, 25, 37, '轰隆隆给你考虑就孟潞', '2013-12-09 23:11:25'),
(145, 25, 37, '轰隆隆给你考虑就孟潞', '2013-12-09 23:11:25'),
(139, 23, 29, 'djggjcn', '2013-12-04 09:00:19'),
(140, 24, 29, 'djfjgkgjjjvh', '2013-12-04 09:02:15'),
(141, 24, 29, 'dhkfjjgh', '2013-12-04 09:02:49'),
(146, 25, 42, '我也来说两句！', '2014-01-15 00:46:18'),
(147, 24, 42, '哈哈哈哈哈哈！', '2014-01-15 00:47:22'),
(148, 23, 42, '哦哦哦哦！', '2014-01-15 00:47:47');

-- --------------------------------------------------------

--
-- 表的结构 `yk_company`
--
-- 创建时间: 2014 年 01 月 08 日 15:22
-- 最后更新: 2014 年 01 月 08 日 15:23
--

CREATE TABLE IF NOT EXISTS `yk_company` (
  `cid` int(1) unsigned NOT NULL auto_increment,
  `companyname` varchar(100) NOT NULL COMMENT '公司名称',
  `description` varchar(9999) default NULL COMMENT '公司简介',
  `logo` varchar(100) default NULL COMMENT '公司图片',
  `url` varchar(50) default NULL COMMENT '公司地址',
  `create_time` date NOT NULL COMMENT '添加时间',
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `yk_company`
--

INSERT INTO `yk_company` (`cid`, `companyname`, `description`, `logo`, `url`, `create_time`) VALUES
(1, '苏州塞拉唯-集美', '<p class="w640" style="font-size:14px;color:#4B4B4B;font-family:arial, 宋体;background-color:#FFFFFF;">\r\n	“塞拉唯”源自法语“c''est la vie”——这就是生活。<br />\r\n苏州塞拉唯贸易有限公司是体验式主题会所运营的服务中心（品牌运营中心）由一群热爱生活之美并具有创新理念的人成立了塞拉唯•服务中心，期待和你们一起发现生活之美，这个城市独有的文化会和我们的理念高度融合。<br />\r\n1、为会所提供整体营销托管、行业代购、运营助教、整体策划设计。。。<br />\r\n2、为会所提供快捷、专业、丰富的多元化服务与用户体验。。。<br />\r\n3、为会所建立精准的客户数据库（新型的数据库营销）。。。\r\n</p>\r\n<ul class="clearfix" style="font-size:14px;color:#4B4B4B;font-family:arial, 宋体;background-color:#FFFFFF;">\r\n	<li>\r\n		<span style="color:#707070;">公司名称：</span>苏州塞拉唯贸易有限公司\r\n	</li>\r\n	<li>\r\n		<span style="color:#707070;">公司规模：</span>20人以下\r\n	</li>\r\n	<li>\r\n		<span style="color:#707070;">公司行业：</span>快速消费品(食品/饮料/烟酒/化妆品)\r\n	</li>\r\n	<li>\r\n		<span style="color:#707070;">公司类型：</span>其他\r\n	</li>\r\n	<li>\r\n		<span style="color:#707070;">联系人：</span>查小姐\r\n	</li>\r\n	<li>\r\n		<span style="color:#707070;">联系电话：</span>68181599\r\n	</li>\r\n	<li>\r\n		<span style="color:#707070;">公司地址：</span>苏州高新区邓尉路9号润捷广场南楼1-208室\r\n	</li>\r\n</ul>', 'company/1379466018.jpg', '0', '2013-09-22');

-- --------------------------------------------------------

--
-- 表的结构 `yk_forum`
--
-- 创建时间: 2014 年 01 月 08 日 15:22
-- 最后更新: 2014 年 01 月 08 日 15:22
--

CREATE TABLE IF NOT EXISTS `yk_forum` (
  `fid` int(10) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `image` varchar(150) default NULL,
  `createtime` datetime NOT NULL,
  PRIMARY KEY  (`fid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `yk_forum`
--

INSERT INTO `yk_forum` (`fid`, `name`, `image`, `createtime`) VALUES
(1, '红酒', 'background/default/background.jpg', '2013-09-12 17:36:23');

-- --------------------------------------------------------

--
-- 表的结构 `yk_photo`
--
-- 创建时间: 2014 年 01 月 08 日 15:22
-- 最后更新: 2014 年 01 月 08 日 15:22
--

CREATE TABLE IF NOT EXISTS `yk_photo` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `cid` smallint(10) unsigned NOT NULL,
  `title` varchar(50) NOT NULL,
  `img` varchar(100) NOT NULL,
  `intro` text character set ucs2 NOT NULL,
  `is_full` varchar(5) NOT NULL,
  `create_time` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- 转存表中的数据 `yk_photo`
--

INSERT INTO `yk_photo` (`id`, `cid`, `title`, `img`, `intro`, `is_full`, `create_time`) VALUES
(1, 8, '美丽苏州1', 'photo/1.jpg', '            美丽苏州1美丽苏州1美丽苏州1美丽苏州1美丽苏州1美丽苏州1美丽苏州1美丽苏州1美丽苏州1美丽苏州1美丽苏州1美丽苏州1美丽苏州1美丽苏州1美丽苏州1美丽苏州1美丽苏州1美丽苏州1', '0', '2013-09-24 15:33:33'),
(2, 8, '美丽苏州2', 'photo/2.jpg', '美丽苏州2美丽苏州2美丽苏州2美丽苏州2', '0', '2013-09-12 00:00:00'),
(3, 8, '', 'photo/3.jpg', '美丽苏州3美丽苏州3美丽苏州3美丽苏州3美丽苏州3美丽苏州3美丽苏州3', '0', '2013-09-12 10:24:09'),
(4, 8, '', 'photo/4.jpg', '                        美丽苏州4美丽苏州4美丽苏州4美丽苏州4美丽苏州4美丽苏州4美丽苏州4美丽苏州4美丽苏州4                        ', '1', '2013-09-22 15:20:23'),
(5, 8, '美丽苏州5', 'photo/5.jpg', '', '1', '2013-09-12 10:24:48'),
(6, 8, '美丽苏州6', 'photo/6.jpg', '                        美丽苏州6美丽苏州6美丽苏州6美丽苏州6美丽苏州6美丽苏州6美丽苏州6美丽苏州6美丽苏州6美丽苏州6美丽苏州6美丽苏州6美丽苏州6美丽苏州6美丽苏州6美丽苏州6美丽苏州6美丽苏州6美丽苏州6                                                                                    ', '1', '2013-09-22 15:20:17'),
(20, 1, '名称名称', 'photo/201312022819.jpg', '简介简介   ', '0', '2013-12-02 15:44:49'),
(23, 1, '名称名称名称', 'photo/201312023698.jpg', '简介简介简介         ', '1', '2013-12-02 15:45:06'),
(24, 2, '衣服名称', 'photo/201312024725.jpg', '衣服简介', '1', '2013-12-02 15:46:58'),
(25, 3, '油画名称', 'photo/201312021064.jpg', '油画简介           ', '1', '2013-12-02 15:46:09');

-- --------------------------------------------------------

--
-- 表的结构 `yk_photo_category`
--
-- 创建时间: 2014 年 01 月 08 日 15:22
-- 最后更新: 2014 年 01 月 08 日 15:22
--

CREATE TABLE IF NOT EXISTS `yk_photo_category` (
  `id` int(12) unsigned NOT NULL auto_increment COMMENT '商品类别ID',
  `name` varchar(50) NOT NULL COMMENT '商品类别名称',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `yk_photo_category`
--

INSERT INTO `yk_photo_category` (`id`, `name`) VALUES
(1, '吃'),
(2, '衣'),
(3, '文'),
(8, '葡萄树');

-- --------------------------------------------------------

--
-- 表的结构 `yk_post`
--
-- 创建时间: 2014 年 01 月 08 日 15:22
-- 最后更新: 2014 年 01 月 08 日 15:22
--

CREATE TABLE IF NOT EXISTS `yk_post` (
  `pid` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `create_time` datetime NOT NULL,
  `commenttime` datetime default NULL,
  PRIMARY KEY  (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- 转存表中的数据 `yk_post`
--

INSERT INTO `yk_post` (`pid`, `uid`, `subject`, `message`, `create_time`, `commenttime`) VALUES
(25, 38, '工具玉兔里', '=咯过马路图', '2013-12-04 09:42:42', NULL),
(23, 29, '新信息', '你咯口哦', '2013-12-04 09:00:01', NULL),
(24, 37, 'dhjfh', 'fhgfjvjfhh', '2013-12-04 09:01:38', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `yk_product`
--
-- 创建时间: 2014 年 01 月 08 日 15:22
-- 最后更新: 2014 年 01 月 08 日 15:23
--

CREATE TABLE IF NOT EXISTS `yk_product` (
  `pid` int(12) unsigned NOT NULL auto_increment COMMENT '商品ID',
  `pname` varchar(50) NOT NULL COMMENT '商品名称',
  `price` float unsigned NOT NULL COMMENT '商品价格',
  `shortdesc` varchar(50) NOT NULL COMMENT '商品简介',
  `content` text COMMENT '商品详情',
  `picture` varchar(500) default NULL COMMENT '商品图片',
  `cat_id` smallint(5) NOT NULL COMMENT '商品类别',
  `createtime` varchar(50) NOT NULL COMMENT '添加时间',
  `updatetime` varchar(50) NOT NULL COMMENT '更新时间',
  PRIMARY KEY  (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- 转存表中的数据 `yk_product`
--

INSERT INTO `yk_product` (`pid`, `pname`, `price`, `shortdesc`, `content`, `picture`, `cat_id`, `createtime`, `updatetime`) VALUES
(11, '圣.艾美隆 拉卡酒庄干红', 0, '亮丽的深红色；果香浓郁，略有烤面告气息和香草芳香；结构平衡、细致、优雅，余味悠长！', '<span style="background-color:#FFFFFF;"><strong>风土条件：</strong>粘土地质，大面积的石灰石，覆盖深层砂砾<br />\r\n<strong>产量限制：</strong>每公倾4800公升以下<br />\r\n<strong>葡萄品种：</strong>45%赤霞珠（Cabernet Sauvignon）；45%梅鹿辄（Merlot）；10%品丽珠（Cabernet Franc）；&nbsp;<br />\r\n<strong>树龄：</strong>30年&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br />\r\n<strong>栽培及酿造技术：</strong>单杆双臂，绿色栽培；人工采摘。15%手工除梗，不挤压。70%酒在新橡木桶中陈酿18个月，定期搅拌。<br />\r\n<strong>酒精度：</strong>12.5% Vol<br />\r\n<strong>保存方式：</strong>12-18℃恒温，相对湿度60-70%，避光，防震，无异味<br />\r\n<strong>芳香：</strong>散发着黑加仑、青草和浆果的浓郁芳香。<br />\r\n<strong>颜色：</strong>丰沛的红色<br />\r\n<strong>配餐建议：</strong>适宜与红肉、烧烤牛肉和蓝纹奶酪搭配食用。<br />\r\n<strong>口感：</strong>酒体饱满，单宁坚实而不失柔滑，余味悠长。<br />\r\n<strong>品评：</strong>酒体醇厚丰满，和谐绵长，并带着玫瑰、桑果、甘草和可可的芳香，拥有浓郁的酒香。</span><span style="font-family:Arial, Helvetica, sans-serif;line-height:normal;background-color:#FFFFFF;">&nbsp;</span>', 'product_pic/1385969891.jpg', 1, '1379055863', '1385969891'),
(12, '法国金尊堡干红', 0, '买就送 维特酒 法国原瓶进口红酒 金尊干红葡萄酒 特价包邮', '<p style="color:#404040;font-family:tahoma, arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	厂名：法国白马高酒庄\r\n</p>\r\n<p style="color:#404040;font-family:tahoma, arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	厂址：奥克产区厂家\r\n</p>\r\n<p style="color:#404040;font-family:tahoma, arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	联系方式：400-800-8135\r\n</p>\r\n<p style="color:#404040;font-family:tahoma, arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	配料表：西拉 歌海娜 慕合怀特\r\n</p>\r\n<p style="color:#404040;font-family:tahoma, arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	储藏方法：避光恒温保存\r\n</p>\r\n<p style="color:#404040;font-family:tahoma, arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	保质期：3650 天\r\n</p>\r\n<p style="color:#404040;font-family:tahoma, arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	食品添加剂：无\r\n</p>\r\n<p style="color:#404040;font-family:tahoma, arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	体积(ml): 750\r\n</p>\r\n<p style="color:#404040;font-family:tahoma, arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	品牌: 金尊葡萄\r\n</p>\r\n<p style="color:#404040;font-family:tahoma, arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	酒种类: 红葡萄酒葡萄酒\r\n</p>\r\n<p style="color:#404040;font-family:tahoma, arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	产地: 法国产区\r\n</p>', 'product_pic/1385969804.jpg', 1, '1379056105', '1385969804'),
(13, '贝蒂酒庄干红', 0, '顺滑，具有黑色水果的味道详情请登录：http://www.9998.TV/company/junka', '原产地：法国&nbsp;<br />\r\n产区：波尔多法定产区 AOC BORDEAUX&nbsp;<br />\r\n级别：AOC &nbsp;<br />\r\n葡萄品种：70% 梅洛 &nbsp;30% 赤霞珠&nbsp;<br />\r\n葡萄树龄：20 年&nbsp;<br />\r\n葡萄园面积：10公顷&nbsp;<br />\r\n土壤：石灰岩沙砾土&nbsp;<br />\r\n酿造：传统方法酿造，不锈钢酒桶培育。&nbsp;<br />\r\n配餐建议：红肉、白肉、奶酪&nbsp;<br />\r\n颜色：红宝石的漂亮色泽&nbsp;<br />\r\n香味：香味细腻，一半水果味，一半花香味&nbsp;<br />\r\n口感：顺滑，具有黑色水果的味道详情请登录：http://www.9998.TV/company/junkaiyue/121212。<br />', 'product_pic/1385969684.jpg', 1, '1379056200', '1385969684'),
(14, '夏天新款旗袍', 0, '夏天新款旗袍简介', '<ul class="attributes-list" style="color:#404040;font-family:tahoma, arial, 宋体;">\r\n	<li style="text-indent:5px;">\r\n		品牌类型:&nbsp;时尚潮牌\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		袖长:&nbsp;短袖（袖长&lt;35cm）\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		货号:&nbsp;B6640T\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		领型:&nbsp;V领\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		颜色:&nbsp;白色&nbsp;黑色&nbsp;蓝色&nbsp;灰色&nbsp;2227黑&nbsp;2227灰&nbsp;2232紫&nbsp;2232黄&nbsp;2232灰&nbsp;2232黑&nbsp;2232白\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		尺码:&nbsp;165/85(M)&nbsp;170/90(L)&nbsp;175/95(XL)&nbsp;180/100(XXL)&nbsp;两件59元，三件79元包邮。&nbsp;仅此一天，品质七天无理由退换。\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		面料分类:&nbsp;其他针织布\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		款式细节:&nbsp;异色包边/镶边\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		工艺处理:&nbsp;免烫处理\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		品牌:&nbsp;丹杰士\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		袖型:&nbsp;常规袖\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		花型图案:&nbsp;纯色\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		版型:&nbsp;修身型\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		主材含量:&nbsp;棉质\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		适用季节:&nbsp;夏\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		年份:&nbsp;2013\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		场合:&nbsp;日常\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		消费群体:&nbsp;青年\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		男装-面料材质:&nbsp;棉\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		男装-基础风格:&nbsp;时尚都市\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		男装-细分风格:&nbsp;潮\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		T恤-印花主题分类:&nbsp;抽象图案\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		男装-纱支等级分类:&nbsp;细支纱（28s-60s）\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		男装-纱线后加工分类:&nbsp;烧毛\r\n	</li>\r\n</ul>', 'product_pic/1385970072.jpg', 2, '1379056331', '1385970072'),
(15, '传统旗袍', 0, '传统旗袍简介', '<ul class="attributes-list" style="color:#404040;font-family:tahoma, arial, 宋体;">\r\n	<li style="text-indent:5px;">\r\n		袖长:&nbsp;长袖（袖长&gt;57cm）\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		货号:&nbsp;001\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		版型:&nbsp;修身型\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		领型:&nbsp;扣领尖领\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		颜色:&nbsp;黑色&nbsp;白色\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		尺码:&nbsp;170M&nbsp;175L&nbsp;180XL&nbsp;185XXL\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		品牌:&nbsp;Meters Bonwe/美特斯邦威\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		面料花型:&nbsp;碎花\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		面料主材质:&nbsp;棉质\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		棉含量:&nbsp;95%以上\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		年份:&nbsp;2013\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		场合:&nbsp;休闲\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		适用季节:&nbsp;夏\r\n	</li>\r\n</ul>', 'product_pic/1385970036.jpg', 2, '1379056389', '1385970036'),
(16, '旗袍古装', 0, '旗袍古装简介', '<ul class="attributes-list" style="color:#404040;font-family:tahoma, arial, 宋体;">\r\n	<li style="text-indent:5px;">\r\n		袖长:&nbsp;长袖（袖长&gt;57cm）\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		货号:&nbsp;15\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		领型:&nbsp;圆领\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		颜色:&nbsp;白色\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		尺码:&nbsp;女S码：高155厘米以上重90斤以下&nbsp;女M码：高158至163厘米以下重100斤以下&nbsp;女L码：高160至165厘米以下重110斤以下&nbsp;女XL码：高163至170厘米以下重120斤以下&nbsp;\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		品牌:&nbsp;人生不设限\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		袖型:&nbsp;常规袖\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		花型图案:&nbsp;字母数字\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		版型:&nbsp;宽松型\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		主材含量:&nbsp;棉质\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		棉含量:&nbsp;80%-89%\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		场合:&nbsp;休闲\r\n	</li>\r\n</ul>', 'product_pic/1385969990.jpg', 2, '1379056449', '1385969990'),
(17, '彩色麋鹿油画', 1548, '奇居良品 现代家居装饰画纯手工油画客厅挂画壁画 彩色麋鹿油画', '<p class="attr-list-hd tm-clear" style="color:#999999;font-family:tahoma, arial, 宋体;">\r\n	<span style="font-weight:700;">产品参数：</span>\r\n</p>\r\n<ul id="J_AttrUL" style="color:#404040;font-family:tahoma, arial, 宋体;">\r\n	<li style="vertical-align:top;color:#666666;">\r\n		装裱方式:&nbsp;有框\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		颜色分类:&nbsp;彩色麋鹿油画\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		组合形式:&nbsp;单幅\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		图案:&nbsp;动物\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		工艺:&nbsp;手绘\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		长*宽（CM）:&nbsp;其他正方形尺寸\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		类型:&nbsp;35mm\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		图片形式:&nbsp;平面\r\n	</li>\r\n	<li id="J_attrBrandName" style="vertical-align:top;color:#666666;">\r\n		品牌:&nbsp;Create for Life/奇居良品\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		货号:&nbsp;ZSH0129\r\n	</li>\r\n</ul>', 'product_pic/1379057994.jpg', 3, '1379057994', '1379057994'),
(18, '客厅装饰画', 46.8, '客厅装饰画纯手绘油画单拼挂画玄关壁电表箱遮挡画无框画厚度3cm', '<ul class="attributes-list" style="color:#404040;font-family:tahoma, arial, 宋体;">\r\n	<li style="text-indent:5px;">\r\n		装裱方式:&nbsp;无框\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		颜色分类:&nbsp;100%纯手绘&nbsp;100%纯手绘\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		组合形式:&nbsp;单幅\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		图案:&nbsp;花卉\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		工艺:&nbsp;手绘油画\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		长*宽（CM）:&nbsp;40x70cm&nbsp;50x90cm&nbsp;60x120cm&nbsp;70x140cm&nbsp;75x150cm&nbsp;80x160cm&nbsp;90x180cm画芯&nbsp;30x50cm\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		类型:&nbsp;30mm厚板\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		图片形式:&nbsp;立体画\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		品牌:&nbsp;WZ-画之家\r\n	</li>\r\n	<li style="text-indent:5px;">\r\n		货号:&nbsp;WZ015\r\n	</li>\r\n</ul>', 'product_pic/1379058044.jpg', 3, '1379058044', '1379058044'),
(19, '青菜扁豆', 0, '青菜扁豆简介', '<p class="attr-list-hd tm-clear" style="color:#999999;font-family:tahoma, arial, 宋体;">\r\n	<span style="font-weight:700;">产品参数：</span> \r\n</p>\r\n<ul id="J_AttrUL" style="color:#404040;font-family:tahoma, arial, 宋体;">\r\n	<li style="vertical-align:top;color:#666666;">\r\n		体积(含包装):&nbsp;（L）495mm*(W)195mm*（H）470mm\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		兼容机价格区间:&nbsp;5000-6999\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		重量(含包装):&nbsp;15KG左右\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		配置类型:&nbsp;豪华发烧型\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		兼容机CPU品牌:&nbsp;INTEL\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		兼容机INTEL型号:&nbsp;其它\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		兼容机主板芯片组:&nbsp;其它主板芯片组\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		兼容机内存容量:&nbsp;8g\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		显卡类别:&nbsp;独立显卡\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		独立显卡型号:&nbsp;其它独立显卡型号\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		兼容机显卡容量:&nbsp;2048m\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		兼容机硬盘容量:&nbsp;500G\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		光驱类型:&nbsp;无光驱\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		兼容机电源功率:&nbsp;450w\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		成色:&nbsp;全新\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		同城服务:&nbsp;同城物流送货上门\r\n	</li>\r\n	<li style="vertical-align:top;color:#666666;">\r\n		显示器尺寸:&nbsp;不含显示器\r\n	</li>\r\n</ul>', 'product_pic/1385970201.jpg', 4, '1379058403', '1385970201'),
(20, '有机食品', 0, '有机食品简介', '<p style="color:#404040;font-family:tahoma, arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;">\r\n	有机食品详情\r\n</p>', 'product_pic/1385970164.jpg', 4, '1379058462', '1385970164'),
(21, '蔬菜包', 0, '蔬菜包简介', '<p style="font-family:tahoma, arial, 宋体, sans-serif;background-color:#FFFFFF;">\r\n	<span><span style="line-height:24px;">蔬菜包详情</span></span>\r\n</p>', 'product_pic/1385970123.jpg', 4, '1379058576', '1385970123');

-- --------------------------------------------------------

--
-- 表的结构 `yk_product_category`
--
-- 创建时间: 2014 年 01 月 08 日 15:22
-- 最后更新: 2014 年 01 月 08 日 15:22
--

CREATE TABLE IF NOT EXISTS `yk_product_category` (
  `id` int(12) unsigned NOT NULL auto_increment COMMENT '商品类别ID',
  `name` varchar(50) NOT NULL COMMENT '商品类别名称',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `yk_product_category`
--

INSERT INTO `yk_product_category` (`id`, `name`) VALUES
(1, '吃'),
(2, '衣'),
(3, '文'),
(4, '其他');

-- --------------------------------------------------------

--
-- 表的结构 `yk_review`
--
-- 创建时间: 2014 年 01 月 08 日 15:22
-- 最后更新: 2014 年 01 月 15 日 00:45
--

CREATE TABLE IF NOT EXISTS `yk_review` (
  `review_id` int(12) unsigned NOT NULL auto_increment COMMENT 'id',
  `aid` int(12) NOT NULL COMMENT '文章id',
  `uid` int(12) NOT NULL COMMENT '用户id',
  `review_content` varchar(255) NOT NULL COMMENT '评论内容',
  `type` smallint(1) unsigned zerofill default '1' COMMENT '1-文章，2-视频，3-分享',
  `create_time` varchar(50) NOT NULL COMMENT '评论时间',
  PRIMARY KEY  (`review_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=168 ;

--
-- 转存表中的数据 `yk_review`
--

INSERT INTO `yk_review` (`review_id`, `aid`, `uid`, `review_content`, `type`, `create_time`) VALUES
(161, 21, 38, '公积', 2, '1386121479'),
(162, 22, 29, '好', 2, '1386123100'),
(163, 21, 29, 'ghjk', 2, '1386445136'),
(164, 15, 29, '空间看你就', 2, '1386601718'),
(165, 38, 37, '孔卡', 3, '1386601833'),
(166, 38, 37, '孔卡', 3, '1386601834'),
(154, 39, 37, '喽', 3, '1386087173'),
(155, 37, 37, 'dgddh', 3, '1386087203'),
(156, 39, 37, '你看看', 3, '1386087258'),
(157, 15, 29, '好好好', 1, '1386116839'),
(158, 15, 29, '金里几天才不知', 1, '1386116869'),
(159, 16, 29, '去看看可', 1, '1386116895'),
(160, 16, 29, '广口哦路哦图库糊涂', 1, '1386116920'),
(167, 47, 42, '测试成功！', 3, '1389717903');

-- --------------------------------------------------------

--
-- 表的结构 `yk_share`
--
-- 创建时间: 2014 年 01 月 08 日 15:22
-- 最后更新: 2014 年 01 月 15 日 00:50
--

CREATE TABLE IF NOT EXISTS `yk_share` (
  `share_id` int(12) unsigned NOT NULL auto_increment COMMENT 'ID',
  `share_title` varchar(50) NOT NULL COMMENT '标题',
  `share_content` text NOT NULL COMMENT '内容',
  `share_pic` varchar(500) NOT NULL COMMENT '图片',
  `user_id` int(12) NOT NULL COMMENT '用户ID',
  `review_number` smallint(5) default '0' COMMENT '评论个数',
  `create_time` varchar(20) NOT NULL COMMENT '分享日期',
  PRIMARY KEY  (`share_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=48 ;

--
-- 转存表中的数据 `yk_share`
--

INSERT INTO `yk_share` (`share_id`, `share_title`, `share_content`, `share_pic`, `user_id`, `review_number`, `create_time`) VALUES
(35, '分享05', '会所负责人分享内容介绍会所负责人分享内容介绍会所负责人分享内容介绍会所负责人分享内容介绍会所负责人分享内容介绍会所负责人分享内容介绍会所负责人分享内容介绍会所负责人分享内容介绍', 'share_pic/1386308551.jpg', 29, 0, '2013.12.6'),
(36, '分享04', '会所负责人分享内容介绍会所负责人分享内容介绍会所负责人分享内容介绍会所负责人分享内容介绍会所负责人分享内容介绍会所负责人分享内容介绍', 'share_pic/1386308534.jpg', 29, 0, '2013.12.6'),
(37, '分享03', '会所负责人分享内容介绍会所负责人分享内容介绍会所负责人分享内容介绍会所负责人分享内容介绍', 'share_pic/1386308529.jpg', 29, 1, '2013.12.6'),
(38, '分享02', '会所负责人分享内容介绍会所负责人分享内容介绍', 'share_pic/1386308523.jpg', 29, 2, '2013.12.6'),
(39, '分享01', '会所负责人分享内容介绍会所负责人分享内容介绍', 'share_pic/1386308519.jpg', 29, 2, '2013.12.6'),
(47, '空间分享', '测试测试测试', 'share_pic/1389717859.jpg', 42, 1, '2014.1.15');

-- --------------------------------------------------------

--
-- 表的结构 `yk_user`
--
-- 创建时间: 2014 年 01 月 08 日 15:22
-- 最后更新: 2014 年 01 月 15 日 00:51
--

CREATE TABLE IF NOT EXISTS `yk_user` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `club_id` smallint(5) unsigned NOT NULL default '0',
  `user_name` varchar(20) NOT NULL,
  `true_name` varchar(20) NOT NULL,
  `club_name` varchar(20) NOT NULL,
  `user_password` varchar(64) NOT NULL,
  `user_head` varchar(100) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `is_admin` smallint(1) unsigned NOT NULL default '0',
  `user_type` varchar(10) NOT NULL,
  `create_time` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=43 ;

--
-- 转存表中的数据 `yk_user`
--

INSERT INTO `yk_user` (`id`, `club_id`, `user_name`, `true_name`, `club_name`, `user_password`, `user_head`, `contact`, `phone`, `is_admin`, `user_type`, `create_time`) VALUES
(37, 9, '云库科技', '云库', '', 'e10adc3949ba59abbe56e057f20f883e', 'userhead/1386048452.jpg', '0', '123456789', 1, '会所负责人', '2013-12-03 13:27:32'),
(42, 9, '醉倾狂', '云库', '', '9adaa75789b3c0a693f9a8759e1abbfb', 'userhead/1389717770.jpg', '0', '123456789', 0, '会所负责人', '2014-01-15 00:42:50'),
(29, 9, 'zk', '云库', '', 'ae7b7c53c828f59efc0f1e07a1af72d5', 'userhead/default.jpg', '0', '123456789', 1, '会所负责人', '2013-10-24 13:11:57'),
(34, 9, 'wx', '云库', '', '202cb962ac59075b964b07152d234b70', 'userhead/1385371728.jpg', '0', '123456789', 0, '会所负责人', '2013-11-25 17:28:48'),
(38, 1, '塞拉唯', 'wx', '', 'e10adc3949ba59abbe56e057f20f883e', 'userhead/1386121299.jpg', '0', '123456', 0, '会所负责人', '2013-12-04 09:41:39');

-- --------------------------------------------------------

--
-- 表的结构 `yk_video`
--
-- 创建时间: 2014 年 01 月 08 日 15:22
-- 最后更新: 2014 年 01 月 08 日 15:22
--

CREATE TABLE IF NOT EXISTS `yk_video` (
  `video_id` int(12) unsigned NOT NULL auto_increment COMMENT '视频ID',
  `video_name` varchar(50) NOT NULL COMMENT '视频名称',
  `video_length` varchar(50) NOT NULL COMMENT '视频时长',
  `video_url` varchar(255) NOT NULL COMMENT '视频URL',
  `content` text COMMENT '描述',
  `video_image` varchar(255) default NULL COMMENT '视频缩略图',
  `review_number` smallint(5) default '0' COMMENT '评论个数',
  `create_time` date NOT NULL COMMENT '添加时间',
  `video_category` int(1) NOT NULL default '0' COMMENT '视频类别',
  PRIMARY KEY  (`video_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- 转存表中的数据 `yk_video`
--

INSERT INTO `yk_video` (`video_id`, `video_name`, `video_length`, `video_url`, `content`, `video_image`, `review_number`, `create_time`, `video_category`) VALUES
(15, '为省房租供子女读书,男子井下20年', 'a:3:{i:0;s:2:"00";i:1;s:2:"03";i:2;s:2:"55";}', 'http://player.youku.com/embed/XNjQ0MDc1NDEy', '<p>\r\n	<span>为了省房租来供子女读书，男子在井下住了20年</span> \r\n</p>\r\n<p>\r\n	<span><span>为了省房租来供子女读书，男子在井下住了20年</span><br />\r\n</span> \r\n</p>', 'video_pic/1386299804.png', 1, '2014-01-08', 1),
(21, 'iPhone 6三面显示屏概念机曝光', 'a:3:{i:0;s:2:"00";i:1;s:2:"02";i:2;s:2:"39";}', 'http://player.youku.com/embed/XNjQwMTgwNzg0', '<p>\r\n	iPhone 6三面环绕显示屏概念机曝光\r\n</p>\r\n<p>\r\n	<span>iPhone 6三面环绕显示屏概念机曝光</span>\r\n</p>', 'video_pic/1386299596.png', 1, '2013-12-06', 0),
(22, '工信部4G牌照正式发放', 'a:3:{i:0;s:2:"00";i:1;s:2:"01";i:2;s:2:"19";}', 'http://player.youku.com/embed/XNjQzOTAyMzMy', '<p>\r\n	<span style="color:#444444;font-family:Tahoma, Helvetica, SimSun, sans-serif;font-size:14px;line-height:21px;background-color:#FFFFFF;">工信部：4G牌照正式发放</span> \r\n</p>\r\n<p>\r\n	<span style="color:#444444;font-family:Tahoma, Helvetica, SimSun, sans-serif;font-size:14px;line-height:21px;background-color:#FFFFFF;"><span style="color:#444444;font-family:Tahoma, Helvetica, SimSun, sans-serif;font-size:14px;line-height:21px;background-color:#FFFFFF;">工信部：4G牌照正式发放</span><br />\r\n</span> \r\n</p>', 'video_pic/1386299736.png', 1, '2014-01-08', 1),
(23, '工信部4G牌照正式发放', 'a:3:{i:0;s:2:"00";i:1;s:2:"01";i:2;s:2:"19";}', 'http://player.youku.com/embed/XNjQzOTAyMzMy', '工信部4G牌照正式发放工信部4G牌照正式发放工信部4G牌照正式发放', 'video_pic/1389148641.png', 0, '2014-01-08', 0);
